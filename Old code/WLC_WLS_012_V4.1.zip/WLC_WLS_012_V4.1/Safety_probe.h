#ifndef Safety_probe_h
#define Safety_probe_h

class Sclass
{
   public :
   Sclass();
   void Setup();
   void Rtd_Temp_Update_1();
};

extern Sclass Safety_probe;
#endif
