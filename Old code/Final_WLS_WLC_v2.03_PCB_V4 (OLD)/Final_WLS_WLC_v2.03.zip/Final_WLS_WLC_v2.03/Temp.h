#ifndef Temp_h
#define Temp_h

class Mclass
{
   public :
   Mclass();
   void Setup();
   void RTD_TEMP_CONV();
   void Rtd_Temp_Update();
};

extern Mclass Temp;
#endif
